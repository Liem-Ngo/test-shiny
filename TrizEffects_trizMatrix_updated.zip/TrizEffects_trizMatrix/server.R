
library(shiny)
library(data.table)
library(readxl)

# Read data
my_data1 <- read_excel("triz_39.xlsx")
my_data2 <- read_excel("triz_45.xlsx")
my_data3 <- read_excel("triz_50.xlsx")
my_data7 <- read_excel("aa.xlsx")

shinyServer(function(input, output, session) {
        ####################
        observeEvent(getQueryString(session)$page, {
                currentQueryString <- getQueryString(session)$page # alternative: parseQueryString(session$clientData$url_search)$page
                if(is.null(input$navbarID) || !is.null(currentQueryString) && currentQueryString != input$navbarID){
                        freezeReactiveValue(input, "navbarID")
                        updateNavbarPage(session, "navbarID", selected = currentQueryString)}}, priority = 1)
        
        observeEvent(input$navbarID, {
                currentQueryString <- getQueryString(session)$page # alternative: parseQueryString(session$clientData$url_search)$page
                pushQueryString <- paste0("?page=", input$navbarID)
                if(is.null(currentQueryString) || currentQueryString != input$navbarID){
                        freezeReactiveValue(input, "navbarID")
                        updateQueryString(pushQueryString, mode = "push", session)}}, priority = 0)
        
        #####################
        
        datasetInput1 <-reactive({ 
                b <- strtoi(input$outlook1)
                a <- strtoi(input$windy1)
                v <- unlist(my_data1[a,b])
                bmi<-as.list(strsplit(v, "[,]")[[1]])
                bmi <- unlist(transpose(bmi))
                v <-read.csv("aa.csv", header = TRUE)
                b <- c()
                for (x in bmi) {b=c(b,v[x,1])}
                vv <-read.csv(input$vidu1, header = TRUE,sep =';' )
                bb1 <- c()
                for (x in bmi) {bb1=c(bb1,vv[x,1])}
                emp <- data.frame(
                        No = bmi,
                        "Thủ_Thuật_Sáng_Tạo" = b, 
                        "Ví_Dụ" = bb1,
                        stringsAsFactors = FALSE)})
        output$mymatrix1 <- renderTable({if (input$submitbutton1>0) {isolate(datasetInput1()) }},bordered = TRUE, sanitize.text.function=identity)                 
        ################################        
        
        datasetInput2 <-reactive({ 
                b <- strtoi(input$outlook2)
                a <- strtoi(input$windy2)
                v <- unlist(my_data2[a,b])
                bmi<-as.list(strsplit(v, "[,]")[[1]])
                bmi <- unlist(transpose(bmi))
                v <-read.csv("aa.csv", header = TRUE)
                b <- c()
                for (x in bmi) {b=c(b,v[x,1])}
                vv <-read.csv(input$vidu2, header = TRUE,sep =';' )
                bb <- c()
                for (x in bmi) {bb=c(bb,vv[x,1])}
                emp <- data.frame(
                        No = bmi,
                        "Thủ_Thuật_Sáng_Tạo" = b, 
                        "Ví_Dụ" = bb,
                        stringsAsFactors = FALSE)})
        output$mymatrix2 <- renderTable({
                if (input$submitbutton2>0) { isolate(datasetInput2()) } },bordered = TRUE, sanitize.text.function=identity)                 
##################################        
        datasetInput3 <-reactive({ 
                b <- strtoi(input$outlook3)
                a <- strtoi(input$windy3)
                v <- unlist(my_data3[a,b])
                bmi<-as.list(strsplit(v, "[,]")[[1]])
                bmi <- unlist(transpose(bmi))
                v <-read.csv("aa.csv", header = TRUE)
                b <- c()
                for (x in bmi) {b=c(b,v[x,1])}
                vv <-read.csv(input$vidu3, header = TRUE,sep =';' )
                bb <- c()
                for (x in bmi) {bb=c(bb,vv[x,1])}
                emp <- data.frame(
                        No = bmi,
                        "Thủ_Thuật_Sáng_Tạo" = b, 
                        "Ví_Dụ" = bb,
                        stringsAsFactors = FALSE)})
        # Prediction results table
        output$mymatrix3 <- renderTable({
                if (input$submitbutton3>0) { 
                        isolate(datasetInput3()) } },bordered = TRUE, sanitize.text.function=identity)       
        datasetInput4 <-reactive({ 
                my_data4 <- read_excel(input$vidu4)
                a <- strtoi(input$outlook4)
                b <- strtoi(input$windy4)
                v <- unlist(my_data4[a,b])
                bmi<-as.list(strsplit(v, "[,]")[[1]])
                bmi <- unlist(transpose(bmi))
                v <-read.csv("name_list_topics.csv", header = TRUE)
                b <- c()
                for (x in bmi) {b=c(b,v[x,1])}
                vv <-read.csv("list_topics.csv", header = TRUE,sep =';' )
                bb <- c()
                for (x in bmi) {bb=c(bb,vv[x,1])}
                emp <- data.frame(No = bmi, "Giải_Pháp" = b, "Mô_Tả_Giải_Pháp" = bb,stringsAsFactors = FALSE)})
        
        output$mymatrix4 <- renderTable({
                if (input$submitbutton4>0) { 
                        isolate(datasetInput4()) 
                } 
        },bordered = TRUE, sanitize.text.function=identity)                 
################################        
        datasetInput5 <-reactive({ 
                my_data5 <- read_excel(input$vidu5)
                a <- strtoi(input$outlook5)
                b <- strtoi(input$windy5)
                v <- unlist(my_data5[a,b])
                bmi<-as.list(strsplit(v, "[,]")[[1]])
                bmi <- unlist(transpose(bmi))
                v <-read.csv("name_list_topics.csv", header = TRUE)
                b <- c()
                for (x in bmi) {b=c(b,v[x,1])}
                vv <-read.csv("list_topics.csv", header = TRUE,sep =';' )
                bb <- c()
                for (x in bmi) {bb=c(bb,vv[x,1])}
                emp <- data.frame(No = bmi, "Giải_Pháp" = b, "Mô_Tả_Giải_Pháp" = bb,stringsAsFactors = FALSE)})
        
        output$mymatrix5 <- renderTable({
                if (input$submitbutton5>0) { 
                        isolate(datasetInput5()) 
                } 
        },bordered = TRUE, sanitize.text.function=identity)                 
        
##################################        
        
        datasetInput6 <-reactive({ 
                my_data6 <- read_excel(input$vidu6)
                a <- strtoi(input$outlook6)
                b <- strtoi(input$windy6)
                v <- unlist(my_data6[a,b])
                bmi<-as.list(strsplit(v, "[,]")[[1]])
                bmi <- unlist(transpose(bmi))
                v <-read.csv("name_list_topics.csv", header = TRUE)
                b <- c()
                for (x in bmi) {b=c(b,v[x,1])}
                vv <-read.csv("list_topics.csv", header = TRUE,sep =';' )
                bb <- c()
                for (x in bmi) {bb=c(bb,vv[x,1])}
                emp <- data.frame(No = bmi, "Giải_Pháp" = b, "Mô_Tả_Giải_Pháp" = bb,stringsAsFactors = FALSE)})
        
        output$mymatrix6 <- renderTable({
                if (input$submitbutton6>0) { 
                        isolate(datasetInput6()) } },bordered = TRUE, sanitize.text.function=identity)                 


################################## 
        
        datasetInput7 <-reactive({ 
                bx <- strtoi(input$outlook7)
                #a <- strtoi(input$windy2)
                #v <- unlist(my_data7[1,bx])
                #bmi<-as.list(strsplit(v, "[,]")[[1]])
                #bmi <- unlist(transpose(bmi))
                #v <-read.csv("aa.csv", header = TRUE)
                v <-read.csv("aaa.csv", header = TRUE,sep =';' )
                b <- c()
                b=c(b,v[bx,1])
                
                vv <-read.csv(input$vidu7, header = TRUE,sep =';' )
                bb <- c()
                bb=c(bb,vv[bx,1])
                emp <- data.frame(
                        #No = bmi,
                        "Nội_Dung" = b, 
                        "Ví_Dụ" = bb,
                        stringsAsFactors = FALSE)})
        output$mymatrix7 <- renderTable({
                if (input$submitbutton7>0) { isolate(datasetInput7()) } },bordered = TRUE, sanitize.text.function=identity)        
###################################        
        
})
