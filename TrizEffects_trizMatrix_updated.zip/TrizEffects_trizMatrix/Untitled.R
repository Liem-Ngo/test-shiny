
rsconnect::setAccountInfo(name='triz50', 
                          token='1D6950D1F2608C6EF95E3FB9C7F7403D', 
                          secret='FOeEFAGOQkZG8xESDAwBYFbblSYQXnGw2It0OQuL')
library(rsconnect)
rsconnect::deployApp('/Users/ngo/Downloads/TRIZ/TrizEffects')


install.packages("cpp11")
install.packages("data.table")
install.packages("fansi")
install.packages("hms")
install.packages("pillar")
install.packages("pkgconfig")
install.packages("prettyunits")
install.packages("progress")
install.packages("readxl")
